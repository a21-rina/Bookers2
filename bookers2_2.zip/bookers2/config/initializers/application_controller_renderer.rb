# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = '3f7f838a990b5d2f053f6e6d49242df1909ce45f4da4bf07737852adf6b975c0283e8fdcbc4ff1134090d0a97cc13c88f14a7923326d21c8f9bcffa73cb9f048'
